#!/usr/bin/env node

import { cli as _ } from "@mintlify/cli";
