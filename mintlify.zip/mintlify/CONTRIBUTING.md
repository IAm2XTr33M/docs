# Mintlify CLI

`mintlify` is a wrapper for [@mintlify/cli](https://www.npmjs.com/package/@mintlify/cli).
